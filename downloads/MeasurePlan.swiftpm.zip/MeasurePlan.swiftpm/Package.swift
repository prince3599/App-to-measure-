// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "MeasurePlan",
    platforms: [.iOS("17.0")],
    products: [
        .iOSApplication(
            name: "MeasurePlan",
            targets: ["AppModule"],
            bundleIdentifier: "com.example.measureplan",
            teamIdentifier: "",
            displayVersion: "0.1",
            bundleVersion: "1",
            appIcon: .placeholder(icon: .camera),
            accentColor: .presetColor(.blue),
            supportedDeviceFamilies: [.pad, .phone],
            supportedInterfaceOrientations: [
                .portrait,
                .landscapeRight,
                .landscapeLeft,
                .portraitUpsideDown(.when(deviceFamilies: [.pad])),
            ],
            capabilities: [
                .camera(purposeString: "MeasurePlan uses the camera and LiDAR scanner to measure your room."),
            ]
        ),
    ],
    targets: [
        .executableTarget(name: "AppModule", path: "."),
    ]
)
